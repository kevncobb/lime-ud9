INTRODUCTION
------------
Moderation Sidebar provides an off-canvas menu to moderate the current Entity.
To use the Moderation Sidebar, simply visit any Moderated Entity and click the
"Moderate" button in the Toolbar. This will open and off-canvas menu that
contains contextual actions related to the Moderation module.

REQUIREMENTS
------------
 - Content Moderation

CONFIGURATION
-------------
There is no configuration available for this module.
