<?php

namespace Drupal\fullcalendar_view\Plugin;

use Drupal\Component\Plugin\PluginInspectionInterface;

/**
 * Defines an interface for Fullcalendar view processor plugins.
 */
interface FullcalendarViewProcessorInterface extends PluginInspectionInterface {
}
