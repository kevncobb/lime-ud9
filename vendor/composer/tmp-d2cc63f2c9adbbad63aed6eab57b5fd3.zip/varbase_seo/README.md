# Varbase SEO
---

Provide Search Engine Optimization (SEO) Core features and settings.

Can be installed in the extra components installation step with Varbase.


## Use With [Varbase](https://www.drupal.org/project/varbase) Distribution:
This module is best used with [Varbase](https://www.drupal.org/project/varbase) distribution.

Can be installed with any Drupal 8/9 site.
 Even if installed with the Minimal or Standard profile.
However, using it with [Varbase](https://www.drupal.org/project/varbase) gives you way much more cool stuff!

## [Varbase documentation](https://docs.varbase.vardot.com/dev-docs/understanding-varbase/core-components/varbase-seo)
Check out Varbase documentation for more details.

Join Our Slack Team for Feedback and Support 
http://slack.varbase.vardot.com/

This module is sponsored and developed by [Vardot](https://www.drupal.org/vardot).
