# Varbase Blog
---

This is a [Varbase](https://www.drupal.org/project/varbase) Feature.

Provides Blog post content type and related configuration.

Use Blog to publish blog post by different authors in the
 Blog section of the site.
