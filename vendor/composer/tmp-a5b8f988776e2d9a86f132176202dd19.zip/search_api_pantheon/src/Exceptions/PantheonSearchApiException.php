<?php

namespace Drupal\search_api_pantheon\Exceptions;

/**
 * Pantheon Search API Exception.
 */
class PantheonSearchApiException extends \Exception {
}
