# Varbase Carousels
---
This feature provides the base implementation for the carousels in your website.
Admins will be able to create carousels on the spot and place it anywhere in the
site.

---

Varbase Carousels requires the slick.min.js library.
Download it (https://github.com/kenwheeler/slick)
and place it in the libraries folder (/libraries)

To keep track of the library in your composer.json file of the project, you
could add.
