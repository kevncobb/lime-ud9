BOOK TREE MENU



=== Introduction === 


Book Tree Menu enhanced the default book navigation, and it makes it work as a normal menu. 
Currently, when navigating a Book as an end user, in order to view the child links that are nested in a different submenu than the one you�re on, 
you must first navigate to their parent page, which will then expand the submenu. We would like give the end users the ability to expand and collapse any submenu they choose without having to navigate to their respective parent pages. 
In this case, the end user won�t be able to navigate to a parent page that holds a submenu through the left menu�clicking on the parent link will only expand and collapse the submenu. 
But this if fine as the parent page only serves as a container for the submenu (and has no content other than the Book traversal links). 