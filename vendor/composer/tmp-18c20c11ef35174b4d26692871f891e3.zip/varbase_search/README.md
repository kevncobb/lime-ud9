# Varbase Search
---

This is a [Varbase](https://www.drupal.org/project/varbase) Feature.

Provides search configuration, and offering search capabilities.

### Use With Varbase Distribution:
This module is best used with Varbase distribution.

This module is sponsored and developed by [Vardot](https://www.drupal.org/vardot).
