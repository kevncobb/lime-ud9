# Varbase Landing
---

This is a [Varbase](https://www.drupal.org/project/varbase) Feature.

Provides the basis for Landing Pages, which are built to include appealing
 stacked components that are visually separate.
