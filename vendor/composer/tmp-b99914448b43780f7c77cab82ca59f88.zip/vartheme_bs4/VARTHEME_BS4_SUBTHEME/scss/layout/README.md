Layout — macro arrangement of a web page, including any grid systems.

Layout
Arrangement of elements on the page, including grid systems.

Grid systems should be thought of as shelves. They contain content but are not
content in themselves. You put up your shelves then fill them with your stuff
[i.e. components]. – Harry Roberts, CSS Guidelines

https://drupal.org/docs/develop/standards/css/css-file-organization-for-drupal-8
