<?php

namespace Drupal\menu_item_extras\Entity;

use Drupal\menu_link_content\MenuLinkContentInterface;

/**
 * {@inheritdoc}
 */
interface MenuItemExtrasMenuLinkContentInterface extends MenuLinkContentInterface {}
