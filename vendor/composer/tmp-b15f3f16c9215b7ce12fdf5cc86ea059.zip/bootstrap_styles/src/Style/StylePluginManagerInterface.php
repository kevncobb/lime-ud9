<?php

namespace Drupal\bootstrap_styles\Style;

use Drupal\Component\Plugin\PluginManagerInterface;

/**
 * Defines an interface for the style plugin manager.
 */
interface StylePluginManagerInterface extends PluginManagerInterface {

}
