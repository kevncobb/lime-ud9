### Still to do

- preview form/content editing form ala node preview, saving sets value in field
- swap out class of entity view display using hook_entity_type_alter, take over
  from layout_builder
- subclass \Drupal\layout_builder\Entity\LayoutBuilderEntityViewDisplay::getRuntimeSections
- field for storing selection of layout on content entity
- tests
