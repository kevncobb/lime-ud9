# Varbase Email

Adds email template for Varbase emails
