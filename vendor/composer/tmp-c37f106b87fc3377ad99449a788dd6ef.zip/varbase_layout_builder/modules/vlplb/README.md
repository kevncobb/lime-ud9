# Varbase Landing page (Layout Builder)

Provides Landing page (Layout Builder) content type and related configuration.
Use Landing page (Layout Builder) to build pages with custom sections and
layouts to display content in a modern way.
