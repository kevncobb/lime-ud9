Style Guide Drupal Module http://drupal.org/project/styleguide

Style Guide Documentation on drupal.org http://drupal.org/documentation/modules/styleguide
