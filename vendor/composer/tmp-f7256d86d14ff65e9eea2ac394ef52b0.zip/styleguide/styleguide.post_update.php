<?php

/**
 * @file
 * Post update functions for Styleguide.
 */

/**
 * Clear caches due to changes in service arguments.
 */
function styleguide_post_update_d9_compatibility() {
  // Empty post-update hook.
}
